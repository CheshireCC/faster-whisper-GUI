import os
import sys


if __name__ == "__main__":
    
    os.system("..\\python310\\python.exe ..\\FasterWhisperGUI.py")

